# app/core/output_formatter.py
import os
import logging
import json
import csv
import markdown
import tempfile
from typing import Dict, Any, Optional, List, Union
from datetime import datetime
from pathlib import Path
from app.models import MVPFeatureType

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class OutputFormatter:
    """Formats and saves output based on feature type."""
    
    def __init__(self, results_path: str = None):
        """
        Initialize the output formatter.
        
        Args:
            results_path: Path to save the results
        """
        if results_path is None:
            # Use default path in user's home directory
            home_dir = Path.home()
            results_path = os.path.join(home_dir, ".sagax1", "results")
        
        self.results_path = results_path
        os.makedirs(self.results_path, exist_ok=True)
    
    def format_and_save(self, task_id: str, result: str, feature_type: MVPFeatureType) -> Dict[str, Any]:
        """
        Format the result based on feature type and save to appropriate file.
        
        Args:
            task_id: ID of the task
            result: Result content
            feature_type: Type of feature that generated the result
            
        Returns:
            Dictionary with file information
        """
        try:
            logger.info(f"Formatting result for task {task_id} with feature type {feature_type}")
            
            # Generate timestamp for filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            
            # Format and save based on feature type
            if feature_type == MVPFeatureType.RESEARCH:
                return self._save_research_output(task_id, result, timestamp)
            elif feature_type == MVPFeatureType.YOUTUBE:
                return self._save_youtube_output(task_id, result, timestamp)
            elif feature_type == MVPFeatureType.DATA_ANALYSIS:
                return self._save_data_analysis_output(task_id, result, timestamp)
            elif feature_type == MVPFeatureType.RAG:
                return self._save_rag_output(task_id, result, timestamp)
            elif feature_type == MVPFeatureType.CODE_GENERATION:
                return self._save_code_output(task_id, result, timestamp)
            else:
                # Default to markdown for general tasks
                return self._save_markdown_output(task_id, result, timestamp)
                
        except Exception as e:
            logger.error(f"Error formatting and saving result: {e}")
            # Fallback to simple text file
            return self._save_text_output(task_id, result, timestamp)
    
    def _save_research_output(self, task_id: str, result: str, timestamp: str) -> Dict[str, Any]:
        """
        Save research output as a formatted document (DOCX, PDF, or Markdown).
        
        Args:
            task_id: ID of the task
            result: Result content
            timestamp: Timestamp string
            
        Returns:
            Dictionary with file information
        """
        # For MVP, we'll save as Markdown first
        # In a future version, we could add PDF/DOCX export
        filename = f"{task_id}_research_{timestamp}.md"
        file_path = os.path.join(self.results_path, filename)
        
        # Format as a nicely structured research document
        formatted_result = self._format_research_content(result, task_id)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(formatted_result)
        
        return {
            "file_path": file_path,
            "file_type": "markdown",
            "file_name": filename,
            "task_id": task_id,
            "feature_type": MVPFeatureType.RESEARCH.value,
            "timestamp": timestamp
        }
    
    def _save_youtube_output(self, task_id: str, result: str, timestamp: str) -> Dict[str, Any]:
        """
        Save YouTube search results as a formatted document.
        
        Args:
            task_id: ID of the task
            result: Result content
            timestamp: Timestamp string
            
        Returns:
            Dictionary with file information
        """
        filename = f"{task_id}_youtube_{timestamp}.md"
        file_path = os.path.join(self.results_path, filename)
        
        # Format as a nicely structured list of videos
        formatted_result = self._format_youtube_content(result, task_id)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(formatted_result)
        
        return {
            "file_path": file_path,
            "file_type": "markdown",
            "file_name": filename,
            "task_id": task_id,
            "feature_type": MVPFeatureType.YOUTUBE.value,
            "timestamp": timestamp
        }
    
    def _save_data_analysis_output(self, task_id: str, result: str, timestamp: str) -> Dict[str, Any]:
        """
        Save data analysis results as CSV, JSON, and/or report.
        
        Args:
            task_id: ID of the task
            result: Result content
            timestamp: Timestamp string
            
        Returns:
            Dictionary with file information
        """
        # Save the report as Markdown
        md_filename = f"{task_id}_analysis_{timestamp}.md"
        md_file_path = os.path.join(self.results_path, md_filename)
        
        # Format the analysis report
        formatted_result = self._format_data_analysis_content(result, task_id)
        
        with open(md_file_path, 'w', encoding='utf-8') as f:
            f.write(formatted_result)
        
        # Try to extract any data tables and save as CSV
        csv_file_path = None
        try:
            csv_filename = f"{task_id}_data_{timestamp}.csv"
            csv_file_path = os.path.join(self.results_path, csv_filename)
            
            # Extract tables using simple heuristics
            # A more sophisticated approach would be needed for production
            tables = self._extract_tables_from_markdown(result)
            
            if tables:
                with open(csv_file_path, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    for table in tables:
                        for row in table:
                            writer.writerow(row)
        except Exception as e:
            logger.error(f"Error saving CSV data: {e}")
            csv_file_path = None
        
        return {
            "file_path": md_file_path,
            "csv_file_path": csv_file_path,
            "file_type": "markdown",
            "file_name": md_filename,
            "task_id": task_id,
            "feature_type": MVPFeatureType.DATA_ANALYSIS.value,
            "timestamp": timestamp
        }
    
    def _save_rag_output(self, task_id: str, result: str, timestamp: str) -> Dict[str, Any]:
        """
        Save RAG (Document Q&A) results.
        
        Args:
            task_id: ID of the task
            result: Result content
            timestamp: Timestamp string
            
        Returns:
            Dictionary with file information
        """
        filename = f"{task_id}_document_qa_{timestamp}.md"
        file_path = os.path.join(self.results_path, filename)
        
        # Format as a nicely structured Q&A document
        formatted_result = self._format_rag_content(result, task_id)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(formatted_result)
        
        return {
            "file_path": file_path,
            "file_type": "markdown",
            "file_name": filename,
            "task_id": task_id,
            "feature_type": MVPFeatureType.RAG.value,
            "timestamp": timestamp
        }
    
    def _save_code_output(self, task_id: str, result: str, timestamp: str) -> Dict[str, Any]:
        """
        Save code generation results, potentially in multiple formats.
        
        Args:
            task_id: ID of the task
            result: Result content
            timestamp: Timestamp string
            
        Returns:
            Dictionary with file information
        """
        # First, save the complete output as Markdown
        md_filename = f"{task_id}_code_{timestamp}.md"
        md_file_path = os.path.join(self.results_path, md_filename)
        
        with open(md_file_path, 'w', encoding='utf-8') as f:
            f.write(result)
        
        # Try to extract actual code and save as code file
        code_file_path = None
        try:
            # Try to identify the programming language and code blocks
            code_blocks = self._extract_code_blocks(result)
            
            if code_blocks and len(code_blocks) > 0:
                primary_block = code_blocks[0]  # Use the first/largest code block
                
                language = primary_block.get("language", "txt")
                code_content = primary_block.get("code", "")
                
                # Map language to file extension
                extension_map = {
                    "python": "py",
                    "javascript": "js",
                    "typescript": "ts",
                    "java": "java",
                    "csharp": "cs",
                    "cpp": "cpp",
                    "c++": "cpp",
                    "go": "go",
                    "ruby": "rb",
                    "php": "php",
                    "swift": "swift",
                    "html": "html",
                    "css": "css",
                    "sql": "sql",
                    "shell": "sh",
                    "bash": "sh",
                }
                
                # Get file extension
                extension = extension_map.get(language.lower(), "txt")
                
                # Save code file
                code_filename = f"{task_id}_code_{timestamp}.{extension}"
                code_file_path = os.path.join(self.results_path, code_filename)
                
                with open(code_file_path, 'w', encoding='utf-8') as f:
                    f.write(code_content)
        
        except Exception as e:
            logger.error(f"Error saving code file: {e}")
            code_file_path = None
        
        return {
            "file_path": md_file_path,
            "code_file_path": code_file_path,
            "file_type": "markdown",
            "file_name": md_filename,
            "task_id": task_id,
            "feature_type": MVPFeatureType.CODE_GENERATION.value,
            "timestamp": timestamp
        }
    
    def _save_markdown_output(self, task_id: str, result: str, timestamp: str) -> Dict[str, Any]:
        """
        Save output as Markdown.
        
        Args:
            task_id: ID of the task
            result: Result content
            timestamp: Timestamp string
            
        Returns:
            Dictionary with file information
        """
        filename = f"{task_id}_{timestamp}.md"
        file_path = os.path.join(self.results_path, filename)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(result)
        
        return {
            "file_path": file_path,
            "file_type": "markdown",
            "file_name": filename,
            "task_id": task_id,
            "feature_type": MVPFeatureType.GENERAL.value,
            "timestamp": timestamp
        }
    
    def _save_text_output(self, task_id: str, result: str, timestamp: str) -> Dict[str, Any]:
        """
        Save output as plain text (fallback).
        
        Args:
            task_id: ID of the task
            result: Result content
            timestamp: Timestamp string
            
        Returns:
            Dictionary with file information
        """
        filename = f"{task_id}_{timestamp}.txt"
        file_path = os.path.join(self.results_path, filename)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(result)
        
        return {
            "file_path": file_path,
            "file_type": "text",
            "file_name": filename,
            "task_id": task_id,
            "feature_type": "general",
            "timestamp": timestamp
        }
    
    def _format_research_content(self, content: str, task_id: str) -> str:
        """
        Format research content into a structured document.
        
        Args:
            content: Raw content
            task_id: ID of the task
            
        Returns:
            Formatted content
        """
        # If the content is already well-structured, keep it as is
        if content.startswith("# "):
            return content
        
        # Add a title and structure if not already present
        formatted_content = f"# Research Report\n\n"
        
        # Add task ID and date
        formatted_content += f"**Task ID:** {task_id}  \n"
        formatted_content += f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  \n\n"
        
        # Add the content
        formatted_content += "## Findings\n\n"
        formatted_content += content
        
        return formatted_content
    
    def _format_youtube_content(self, content: str, task_id: str) -> str:
        """
        Format YouTube search results into a structured document.
        
        Args:
            content: Raw content
            task_id: ID of the task
            
        Returns:
            Formatted content
        """
        # If the content is already well-structured, keep it as is
        if content.startswith("# "):
            return content
        
        # Add a title and structure if not already present
        formatted_content = f"# YouTube Video Recommendations\n\n"
        
        # Add task ID and date
        formatted_content += f"**Task ID:** {task_id}  \n"
        formatted_content += f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  \n\n"
        
        # Add the content
        formatted_content += "## Recommended Videos\n\n"
        formatted_content += content
        
        return formatted_content
    
    def _format_data_analysis_content(self, content: str, task_id: str) -> str:
        """
        Format data analysis results into a structured report.
        
        Args:
            content: Raw content
            task_id: ID of the task
            
        Returns:
            Formatted content
        """
        # If the content is already well-structured, keep it as is
        if content.startswith("# "):
            return content
        
        # Add a title and structure if not already present
        formatted_content = f"# Data Analysis Report\n\n"
        
        # Add task ID and date
        formatted_content += f"**Task ID:** {task_id}  \n"
        formatted_content += f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  \n\n"
        
        # Add the content
        formatted_content += "## Analysis Results\n\n"
        formatted_content += content
        
        return formatted_content
    
    def _format_rag_content(self, content: str, task_id: str) -> str:
        """
        Format RAG (Document Q&A) results into a structured document.
        
        Args:
            content: Raw content
            task_id: ID of the task
            
        Returns:
            Formatted content
        """
        # If the content is already well-structured, keep it as is
        if content.startswith("# "):
            return content
        
        # Add a title and structure if not already present
        formatted_content = f"# Document Q&A Results\n\n"
        
        # Add task ID and date
        formatted_content += f"**Task ID:** {task_id}  \n"
        formatted_content += f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  \n\n"
        
        # Add the content
        formatted_content += "## Question and Answer\n\n"
        formatted_content += content
        
        return formatted_content
    
    def _extract_tables_from_markdown(self, content: str) -> List[List[List[str]]]:
        """
        Extract tables from Markdown content.
        
        Args:
            content: Markdown content
            
        Returns:
            List of tables, where each table is a list of rows
        """
        tables = []
        lines = content.split('\n')
        
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            
            # Look for table header (has | characters and a separator line underneath)
            if '|' in line and i + 1 < len(lines) and '---' in lines[i + 1] and '|' in lines[i + 1]:
                # Found a table header
                header_cells = [cell.strip() for cell in line.strip('|').split('|')]
                
                # Skip the separator line
                i += 2
                
                # Process table rows
                rows = [header_cells]
                while i < len(lines) and '|' in lines[i]:
                    row_cells = [cell.strip() for cell in lines[i].strip('|').split('|')]
                    if len(row_cells) == len(header_cells):  # Make sure row has same number of cells as header
                        rows.append(row_cells)
                    i += 1
                
                if len(rows) > 1:  # Only add if we have data rows
                    tables.append(rows)
                continue
            
            i += 1
        
        return tables
    
    def _extract_code_blocks(self, content: str) -> List[Dict[str, str]]:
        """
        Extract code blocks from Markdown content.
        
        Args:
            content: Markdown content
            
        Returns:
            List of dictionaries with language and code
        """
        code_blocks = []
        lines = content.split('\n')
        
        i = 0
        while i < len(lines):
            line = lines[i]
            
            # Look for code block markers
            if line.startswith('```'):
                # Found a code block
                language = line[3:].strip()
                
                # Start collecting code
                code_lines = []
                i += 1
                
                # Read until the end of the code block
                while i < len(lines) and not lines[i].startswith('```'):
                    code_lines.append(lines[i])
                    i += 1
                
                # Skip the closing marker
                if i < len(lines):
                    i += 1
                
                # Add the code block to the list
                code_blocks.append({
                    "language": language,
                    "code": '\n'.join(code_lines)
                })
                continue
            
            i += 1
        
        return code_blocks