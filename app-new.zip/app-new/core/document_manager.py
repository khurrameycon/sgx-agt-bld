# app/core/document_manager.py
import os
import uuid
import logging
import shutil
from pathlib import Path
from typing import List, Dict, Any, Optional
import json

from app.models import DocumentInfo

# Try to import optional dependencies
try:
    import fitz  # PyMuPDF for PDF processing
    PYMUPDF_AVAILABLE = True
except ImportError:
    PYMUPDF_AVAILABLE = False

try:
    import docx
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False

try:
    from sentence_transformers import SentenceTransformer
    import numpy as np
    EMBEDDINGS_AVAILABLE = True
except ImportError:
    EMBEDDINGS_AVAILABLE = False

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DocumentManager:
    """Manager for document processing and RAG functionality."""
    
    def __init__(self, storage_path: str = None):
        """
        Initialize the document manager.
        
        Args:
            storage_path: Path to store documents and embeddings
        """
        if storage_path is None:
            # Use default path in user's home directory
            home_dir = Path.home()
            storage_path = os.path.join(home_dir, ".sagax1", "documents")
        
        self.storage_path = storage_path
        self.documents_path = os.path.join(storage_path, "files")
        self.embeddings_path = os.path.join(storage_path, "embeddings")
        self.chunked_texts_path = os.path.join(storage_path, "chunks")
        
        # Create directories if they don't exist
        os.makedirs(self.documents_path, exist_ok=True)
        os.makedirs(self.embeddings_path, exist_ok=True)
        os.makedirs(self.chunked_texts_path, exist_ok=True)
        
        # Initialize embedding model if available
        self.embedding_model = None
        if EMBEDDINGS_AVAILABLE:
            try:
                self.embedding_model = SentenceTransformer('all-mpnet-base-v2')
                logger.info("Embedding model loaded successfully")
            except Exception as e:
                logger.error(f"Error loading embedding model: {e}")
    
    def save_uploaded_document(self, file_path: str, original_filename: str) -> DocumentInfo:
        """
        Save an uploaded document to the storage.
        
        Args:
            file_path: Temporary path where the file was uploaded
            original_filename: Original name of the file
            
        Returns:
            DocumentInfo object with document metadata
        """
        # Generate a unique ID for the document
        document_id = f"doc_{uuid.uuid4().hex[:8]}"
        
        # Get file extension
        _, file_extension = os.path.splitext(original_filename)
        file_extension = file_extension.lower()
        
        # Create a new filename with the document ID
        new_filename = f"{document_id}{file_extension}"
        new_file_path = os.path.join(self.documents_path, new_filename)
        
        # Copy the file to the storage location
        shutil.copy2(file_path, new_file_path)
        
        # Get file size
        file_size = os.path.getsize(new_file_path)
        
        # Determine file type
        file_type = self._get_file_type(file_extension)
        
        # Extract text content if possible
        content_text = self._extract_text(new_file_path, file_type)
        
        # Create and return document info
        document_info = DocumentInfo(
            filename=original_filename,
            file_path=new_file_path,
            file_type=file_type,
            file_size=file_size,
            content_text=content_text,
            embedding_status=False
        )
        
        # Save document info
        self._save_document_info(document_id, document_info)
        
        # Process embeddings in background if text was extracted
        if content_text:
            # In a production system, this would be done asynchronously
            # For MVP, we'll do it synchronously
            if self.embedding_model:
                self._process_embeddings(document_id, document_info)
        
        return document_info
    
    def get_document(self, document_id: str) -> Optional[DocumentInfo]:
        """
        Get a document by its ID.
        
        Args:
            document_id: ID of the document
            
        Returns:
            DocumentInfo object if found, None otherwise
        """
        document_info_path = os.path.join(self.documents_path, f"{document_id}.json")
        if os.path.exists(document_info_path):
            with open(document_info_path, 'r') as f:
                document_data = json.load(f)
                return DocumentInfo(**document_data)
        return None
    
    def list_documents(self) -> List[DocumentInfo]:
        """
        List all available documents.
        
        Returns:
            List of DocumentInfo objects
        """
        documents = []
        for filename in os.listdir(self.documents_path):
            if filename.endswith('.json'):
                document_id = os.path.splitext(filename)[0]
                document = self.get_document(document_id)
                if document:
                    documents.append(document)
        return documents
    
    def search_documents(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """
        Search documents using the query.
        
        Args:
            query: Search query
            top_k: Number of top results to return
            
        Returns:
            List of document chunks with relevance scores
        """
        if not self.embedding_model:
            logger.warning("Embedding model not available for search")
            return []
        
        # Encode the query
        query_embedding = self.embedding_model.encode(query)
        
        # Search through all document chunks
        results = []
        for chunk_file in os.listdir(self.chunked_texts_path):
            if chunk_file.endswith('.json'):
                with open(os.path.join(self.chunked_texts_path, chunk_file), 'r') as f:
                    chunk_data = json.load(f)
                    
                    # Load the embedding
                    embedding_file = os.path.join(self.embeddings_path, 
                                                f"{chunk_data['chunk_id']}.npy")
                    if os.path.exists(embedding_file):
                        embedding = np.load(embedding_file)
                        
                        # Calculate similarity
                        similarity = np.dot(query_embedding, embedding) / (
                            np.linalg.norm(query_embedding) * np.linalg.norm(embedding))
                        
                        results.append({
                            "document_id": chunk_data["document_id"],
                            "chunk_id": chunk_data["chunk_id"],
                            "content": chunk_data["content"],
                            "similarity": float(similarity),
                            "metadata": chunk_data.get("metadata", {})
                        })
        
        # Sort by similarity (descending) and return top_k results
        results.sort(key=lambda x: x["similarity"], reverse=True)
        return results[:top_k]
    
    def _get_file_type(self, file_extension: str) -> str:
        """
        Determine the file type based on extension.
        
        Args:
            file_extension: File extension
            
        Returns:
            File type string
        """
        extension_map = {
            '.pdf': 'pdf',
            '.docx': 'docx',
            '.doc': 'doc',
            '.txt': 'text',
            '.md': 'markdown',
            '.csv': 'csv',
            '.json': 'json'
        }
        return extension_map.get(file_extension, 'unknown')
    
    def _extract_text(self, file_path: str, file_type: str) -> Optional[str]:
        """
        Extract text content from a document.
        
        Args:
            file_path: Path to the document file
            file_type: Type of the file
            
        Returns:
            Extracted text content if possible, None otherwise
        """
        try:
            if file_type == 'pdf' and PYMUPDF_AVAILABLE:
                return self._extract_text_from_pdf(file_path)
            elif file_type == 'docx' and DOCX_AVAILABLE:
                return self._extract_text_from_docx(file_path)
            elif file_type in ['text', 'markdown', 'json']:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return f.read()
            else:
                logger.warning(f"Text extraction not supported for file type: {file_type}")
                return None
        except Exception as e:
            logger.error(f"Error extracting text from {file_path}: {e}")
            return None
    
    def _extract_text_from_pdf(self, file_path: str) -> str:
        """
        Extract text from a PDF file.
        
        Args:
            file_path: Path to the PDF file
            
        Returns:
            Extracted text content
        """
        document = fitz.open(file_path)
        text = ""
        for page in document:
            text += page.get_text()
        return text
    
    def _extract_text_from_docx(self, file_path: str) -> str:
        """
        Extract text from a DOCX file.
        
        Args:
            file_path: Path to the DOCX file
            
        Returns:
            Extracted text content
        """
        doc = docx.Document(file_path)
        return "\n".join([paragraph.text for paragraph in doc.paragraphs])
    
    def _process_embeddings(self, document_id: str, document_info: DocumentInfo) -> None:
        """
        Process embeddings for a document.
        
        Args:
            document_id: ID of the document
            document_info: Document information
        """
        if not document_info.content_text or not self.embedding_model:
            return
        
        try:
            # Split the content into chunks
            chunks = self._chunk_text(document_info.content_text)
            
            # Process each chunk
            for i, chunk in enumerate(chunks):
                chunk_id = f"{document_id}_chunk_{i}"
                
                # Create chunk metadata
                chunk_data = {
                    "document_id": document_id,
                    "chunk_id": chunk_id,
                    "content": chunk,
                    "metadata": {
                        "original_filename": document_info.filename,
                        "chunk_index": i,
                        "total_chunks": len(chunks)
                    }
                }
                
                # Save chunk data
                chunk_file_path = os.path.join(self.chunked_texts_path, f"{chunk_id}.json")
                with open(chunk_file_path, 'w') as f:
                    json.dump(chunk_data, f)
                
                # Generate and save embedding
                embedding = self.embedding_model.encode(chunk)
                embedding_file_path = os.path.join(self.embeddings_path, f"{chunk_id}.npy")
                np.save(embedding_file_path, embedding)
            
            # Update document info
            document_info.embedding_status = True
            self._save_document_info(document_id, document_info)
            
            logger.info(f"Successfully processed embeddings for document {document_id}")
            
        except Exception as e:
            logger.error(f"Error processing embeddings for document {document_id}: {e}")
    
    def _chunk_text(self, text: str, chunk_size: int = 1000, overlap: int = 200) -> List[str]:
        """
        Split text into overlapping chunks.
        
        Args:
            text: Text content to chunk
            chunk_size: Maximum size of each chunk
            overlap: Overlap between chunks
            
        Returns:
            List of text chunks
        """
        chunks = []
        start = 0
        text_length = len(text)
        
        while start < text_length:
            end = min(start + chunk_size, text_length)
            
            # If we're not at the end of the text, try to find a good breakpoint
            if end < text_length:
                # Look for a newline or period near the end
                for breakpoint in range(end - 1, max(start + chunk_size // 2, start), -1):
                    if text[breakpoint] in ['.', '\n', '!', '?']:
                        end = breakpoint + 1
                        break
            
            # Add the chunk
            chunks.append(text[start:end])
            
            # Move to next chunk with overlap
            start = end - overlap
            if start < 0 or start >= text_length:
                break
        
        return chunks
    
    def _save_document_info(self, document_id: str, document_info: DocumentInfo) -> None:
        """
        Save document info to a JSON file.
        
        Args:
            document_id: ID of the document
            document_info: Document information
        """
        document_info_path = os.path.join(self.documents_path, f"{document_id}.json")
        with open(document_info_path, 'w') as f:
            json.dump(document_info.dict(), f)