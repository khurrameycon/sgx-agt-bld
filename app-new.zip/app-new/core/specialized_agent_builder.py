# app/core/specialized_agent_builder.py
import logging
from typing import List, Dict, Any, Optional
from crewai import Agent, LLM
from langchain.tools import BaseTool

from app.models import TaskAnalysis, AgentSpec, MVPFeatureType
from app.config import get_config
from app.core.agent_builder import AgentBuilder
from app.tools.web_search import create_web_search_tool
from app.tools.youtube_search import create_youtube_search_tool
from app.tools.data_analysis import create_data_analysis_tool
from app.tools.rag import create_rag_tool
from app.tools.code_generation import create_code_generation_tool
from app.core.document_manager import DocumentManager

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SpecializedAgentBuilder:
    """Builds specialized agents for MVP features."""
    
    def __init__(self):
        """Initialize the specialized agent builder."""
        self.config = get_config()
        self.agent_builder = AgentBuilder()
        self.document_manager = DocumentManager()
    
    def build_specialized_agents(self, task_analysis: TaskAnalysis) -> List[Agent]:
        """
        Build specialized agents based on the feature type and task analysis.
        
        Args:
            task_analysis: The analysis of the user task
            
        Returns:
            List of configured CrewAI Agent objects
        """
        feature_type = task_analysis.feature_type
        logger.info(f"Building specialized agents for feature type: {feature_type}")
        
        if feature_type == MVPFeatureType.RESEARCH:
            return self._build_research_agents(task_analysis)
        elif feature_type == MVPFeatureType.YOUTUBE:
            return self._build_youtube_agents(task_analysis)
        elif feature_type == MVPFeatureType.DATA_ANALYSIS:
            return self._build_data_analysis_agents(task_analysis)
        elif feature_type == MVPFeatureType.RAG:
            return self._build_rag_agents(task_analysis)
        elif feature_type == MVPFeatureType.CODE_GENERATION:
            return self._build_code_generation_agents(task_analysis)
        else:
            # Fall back to regular agent building
            return self.agent_builder.build_agents(task_analysis, self.config.max_agents)
    
    def _build_research_agents(self, task_analysis: TaskAnalysis) -> List[Agent]:
        """Build agents for research tasks."""
        agents = []
        
        # Configure LLM
        llm = self._configure_llm()
        
        # Create research agent
        research_agent = Agent(
            role="Research Specialist",
            goal="Find comprehensive and accurate information on the research topic",
            backstory="An expert researcher with skills in gathering, analyzing, and synthesizing information from various sources. I excel at finding accurate and relevant information.",
            verbose=True,
            allow_delegation=True,
            tools=[create_web_search_tool()],
            llm=llm
        )
        agents.append(research_agent)
        
        # Create fact checking agent
        fact_checking_agent = Agent(
            role="Fact Checker",
            goal="Verify the accuracy of information and identify potential biases or inconsistencies",
            backstory="A meticulous fact checker with a strong attention to detail. I ensure that all information is accurate, properly sourced, and unbiased.",
            verbose=True,
            allow_delegation=True,
            tools=[create_web_search_tool()],
            llm=llm
        )
        agents.append(fact_checking_agent)
        
        # Create synthesis agent
        synthesis_agent = Agent(
            role="Information Synthesizer",
            goal="Synthesize research findings into a coherent and comprehensive report",
            backstory="An expert at organizing and synthesizing complex information. I create clear, structured reports that present research findings in an accessible way.",
            verbose=True,
            allow_delegation=True,
            llm=llm
        )
        agents.append(synthesis_agent)
        
        return agents
    
    def _build_youtube_agents(self, task_analysis: TaskAnalysis) -> List[Agent]:
        """Build agents for YouTube search and analysis tasks."""
        agents = []
        
        # Configure LLM
        llm = self._configure_llm()
        
        # Create YouTube search agent
        youtube_search_agent = Agent(
            role="YouTube Content Finder",
            goal="Find the most relevant and high-quality YouTube videos on the specified topic",
            backstory="A specialist in discovering valuable video content across YouTube. I can find educational, entertaining, and informative videos tailored to specific needs.",
            verbose=True,
            allow_delegation=True,
            tools=[create_youtube_search_tool()],
            llm=llm
        )
        agents.append(youtube_search_agent)
        
        # Create content analysis agent
        content_analysis_agent = Agent(
            role="Video Content Analyzer",
            goal="Analyze video content to determine relevance, quality, and educational value",
            backstory="An expert in evaluating video content for its relevance, accuracy, production quality, and educational value. I can identify the most valuable videos on any topic.",
            verbose=True,
            allow_delegation=True,
            llm=llm
        )
        agents.append(content_analysis_agent)
        
        # Create recommendation agent
        recommendation_agent = Agent(
            role="Content Recommender",
            goal="Create a curated list of recommended videos with explanations",
            backstory="A curator skilled in organizing video recommendations into coherent learning paths or collections. I create personalized video recommendations that meet specific needs.",
            verbose=True,
            allow_delegation=True,
            llm=llm
        )
        agents.append(recommendation_agent)
        
        return agents
    
    def _build_data_analysis_agents(self, task_analysis: TaskAnalysis) -> List[Agent]:
        """Build agents for data analysis tasks."""
        agents = []
        
        # Configure LLM
        llm = self._configure_llm()
        
        # Create data cleaning agent
        data_cleaning_agent = Agent(
            role="Data Cleaning Specialist",
            goal="Clean and prepare data for analysis, addressing missing values, outliers, and inconsistencies",
            backstory="An expert in data cleaning and preparation with meticulous attention to detail. I ensure data is ready for accurate analysis.",
            verbose=True,
            allow_delegation=True,
            tools=[create_data_analysis_tool()],
            llm=llm
        )
        agents.append(data_cleaning_agent)
        
        # Create data analysis agent
        data_analysis_agent = Agent(
            role="Data Analyst",
            goal="Analyze data to extract meaningful insights and patterns",
            backstory="A skilled data analyst with expertise in statistical methods and pattern recognition. I transform raw data into meaningful insights.",
            verbose=True,
            allow_delegation=True,
            tools=[create_data_analysis_tool()],
            llm=llm
        )
        agents.append(data_analysis_agent)
        
        # Create data visualization agent
        data_visualization_agent = Agent(
            role="Data Visualization Specialist",
            goal="Create clear and informative visualizations that effectively communicate data insights",
            backstory="An expert in data visualization who knows how to present data in the most compelling and informative way. I translate complex data into accessible visual stories.",
            verbose=True,
            allow_delegation=True,
            tools=[create_data_analysis_tool()],
            llm=llm
        )
        agents.append(data_visualization_agent)
        
        # Create insights agent
        insights_agent = Agent(
            role="Insights Interpreter",
            goal="Interpret data analysis results to provide actionable insights and recommendations",
            backstory="A specialist in translating data findings into practical business insights. I help bridge the gap between raw analysis and strategic decision-making.",
            verbose=True,
            allow_delegation=True,
            llm=llm
        )
        agents.append(insights_agent)
        
        return agents
    
    def _build_rag_agents(self, task_analysis: TaskAnalysis) -> List[Agent]:
        """Build agents for RAG (Retrieval Augmented Generation) tasks."""
        agents = []
        
        # Configure LLM
        llm = self._configure_llm()
        
        # Create document processing agent
        document_processing_agent = Agent(
            role="Document Processor",
            goal="Process and analyze uploaded documents to extract key information",
            backstory="An expert in document analysis and information extraction. I can quickly identify and extract relevant information from various document types.",
            verbose=True,
            allow_delegation=True,
            tools=[create_rag_tool(self.document_manager)],
            llm=llm
        )
        agents.append(document_processing_agent)
        
        # Create retrieval agent
        retrieval_agent = Agent(
            role="Information Retriever",
            goal="Retrieve relevant information from processed documents based on queries",
            backstory="A specialist in information retrieval with expertise in semantic search techniques. I can find the most relevant information for any query.",
            verbose=True,
            allow_delegation=True,
            tools=[create_rag_tool(self.document_manager), create_web_search_tool()],
            llm=llm
        )
        agents.append(retrieval_agent)
        
        # Create answer generation agent
        answer_generation_agent = Agent(
            role="Answer Generator",
            goal="Generate comprehensive and accurate answers based on retrieved information",
            backstory="An expert in generating clear, concise, and informative answers based on retrieved information. I ensure answers are accurate and properly contextualized.",
            verbose=True,
            allow_delegation=True,
            llm=llm
        )
        agents.append(answer_generation_agent)
        
        return agents
    
    def _build_code_generation_agents(self, task_analysis: TaskAnalysis) -> List[Agent]:
        """Build agents for code generation tasks."""
        agents = []
        
        # Configure LLM
        llm = self._configure_llm()
        
        # Create requirements analysis agent
        requirements_agent = Agent(
            role="Requirements Analyst",
            goal="Analyze and clarify software requirements to ensure clear understanding",
            backstory="A requirements specialist who excels at understanding and defining software needs. I translate user requests into clear technical requirements.",
            verbose=True,
            allow_delegation=True,
            llm=llm
        )
        agents.append(requirements_agent)
        
        # Create architecture agent
        architecture_agent = Agent(
            role="Software Architect",
            goal="Design the overall structure and component relationships of the software",
            backstory="An experienced software architect with expertise in designing elegant, scalable software systems. I create blueprints that guide development.",
            verbose=True,
            allow_delegation=True,
            llm=llm
        )
        agents.append(architecture_agent)
        
        # Create code generation agent
        code_generation_agent = Agent(
            role="Code Generator",
            goal="Generate clean, efficient, and well-documented code based on requirements",
            backstory="A skilled programmer with expertise in multiple programming languages. I write high-quality, maintainable code that meets requirements.",
            verbose=True,
            allow_delegation=True,
            tools=[create_code_generation_tool()],
            llm=llm
        )
        agents.append(code_generation_agent)
        
        # Create testing agent
        testing_agent = Agent(
            role="Software Tester",
            goal="Review code for bugs, edge cases, and potential improvements",
            backstory="A meticulous tester with a knack for finding edge cases and potential issues. I ensure code is robust, efficient, and ready for production.",
            verbose=True,
            allow_delegation=True,
            llm=llm
        )
        agents.append(testing_agent)
        
        # Create documentation agent
        documentation_agent = Agent(
            role="Technical Documentation Writer",
            goal="Create clear, comprehensive documentation for the generated code",
            backstory="A documentation specialist who excels at explaining complex technical concepts clearly. I create documentation that helps users understand and use the code effectively.",
            verbose=True,
            allow_delegation=True,
            llm=llm
        )
        agents.append(documentation_agent)
        
        return agents
    
    def _configure_llm(self) -> Optional[LLM]:
        """Configure the LLM for agents."""
        if self.config.use_ollama_for_agents:
            try:
                model_name = f"ollama/{self.config.default_ollama_model_id}"
                llm = LLM(
                    model=model_name,
                    base_url=self.config.ollama_base_url,
                    api_type="ollama"
                )
                logger.info(f"Using Ollama LLM for agents: {model_name}")
                return llm
            except Exception as e:
                logger.error(f"Error creating Ollama LLM: {e}")
        
        return None