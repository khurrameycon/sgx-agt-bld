# app/core/task_analyzer.py
import uuid
import logging
import re
from typing import Dict, List, Any, Optional
from app.models import TaskAnalysis, AgentSpec, WorkflowType, MVPFeatureType, DocumentInfo
from app.core.llm_provider import LLMProvider
from app.core.document_manager import DocumentManager

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TaskAnalyzer:
    """Analyzes user prompts to determine agent requirements and MVP feature type."""
    
    def __init__(self, llm_provider: LLMProvider, document_manager: Optional[DocumentManager] = None):
        """
        Initialize the task analyzer.
        
        Args:
            llm_provider: Provider for LLM inference
            document_manager: Optional document manager for RAG
        """
        self.llm_provider = llm_provider
        self.document_manager = document_manager or DocumentManager()
    
    async def analyze(self, prompt: str, document_ids: List[str] = None) -> TaskAnalysis:
        """
        Analyze the user prompt and determine the optimal agent configuration.
        
        Args:
            prompt: The user's task description
            document_ids: Optional list of document IDs for RAG
            
        Returns:
            TaskAnalysis object with agent specifications
        """
        try:
            # Detect feature type
            feature_type = self._detect_feature_type(prompt)
            logger.info(f"Detected feature type: {feature_type}")
            
            # Get uploaded documents if feature type is RAG
            uploaded_documents = []
            if feature_type == MVPFeatureType.RAG and document_ids:
                for doc_id in document_ids:
                    doc = self.document_manager.get_document(doc_id)
                    if doc:
                        uploaded_documents.append(doc)
            
            # Get analysis from the LLM
            analysis_result = await self.llm_provider.analyze_task(prompt)
            logger.info(f"Received analysis from LLM: {analysis_result}")
            
            # Process the analysis result
            # Make sure workflow_type is one of the allowed values
            if "workflow_type" in analysis_result:
                if analysis_result["workflow_type"].lower() not in ["sequential", "parallel", "hierarchical"]:
                    analysis_result["workflow_type"] = "sequential"
                analysis_result["workflow_type"] = analysis_result["workflow_type"].lower()
            else:
                analysis_result["workflow_type"] = "sequential"
            
            # Ensure task_id is present
            if "task_id" not in analysis_result:
                analysis_result["task_id"] = f"task_{uuid.uuid4().hex[:8]}"
            
            # Set feature type
            analysis_result["feature_type"] = feature_type
            
            # Add uploaded documents
            analysis_result["uploaded_documents"] = uploaded_documents
            
            # Get specialized agents based on feature type
            required_agents = self._get_specialized_agents(feature_type)
            
            # Update required_agents if we have specialized agents
            if required_agents:
                analysis_result["required_agents"] = required_agents
            # Validate required_agents
            elif "required_agents" not in analysis_result or not analysis_result["required_agents"]:
                analysis_result["required_agents"] = self._generate_default_agents()
            
            # Validate dependencies
            if "dependencies" not in analysis_result:
                analysis_result["dependencies"] = self._generate_default_dependencies(analysis_result["required_agents"])
            
            # Convert to TaskAnalysis object
            return TaskAnalysis(**analysis_result)
            
        except Exception as e:
            logger.error(f"Error analyzing task: {e}")
            # Return a default analysis in case of error
            return self._generate_default_analysis(feature_type, document_ids)
    
    def _detect_feature_type(self, prompt: str) -> MVPFeatureType:
        """
        Detect the MVP feature type from the prompt.
        
        Args:
            prompt: The user's task description
            
        Returns:
            Detected MVPFeatureType
        """
        # Convert to lowercase for case-insensitive matching
        prompt_lower = prompt.lower()
        
        # Check for research indicators
        research_indicators = [
            r'\bresearch\b', r'\bfind information\b', r'\bgather data\b', 
            r'\blearn about\b', r'\binvestigate\b', r'\bstudy\b', r'\banalyze information\b'
        ]
        if any(re.search(pattern, prompt_lower) for pattern in research_indicators):
            return MVPFeatureType.RESEARCH
        
        # Check for YouTube indicators
        youtube_indicators = [
            r'\byoutube\b', r'\bvideos\b', r'\bfind videos\b', r'\bvideo content\b',
            r'\bvideo search\b', r'\btutorials\b', r'\bwatch\b'
        ]
        if any(re.search(pattern, prompt_lower) for pattern in youtube_indicators):
            return MVPFeatureType.YOUTUBE
        
        # Check for data analysis indicators
        data_analysis_indicators = [
            r'\bdata analysis\b', r'\banalyze data\b', r'\bstatistics\b', r'\bvisualize data\b',
            r'\bchart\b', r'\bgraph\b', r'\btrends\b', r'\bdata visualization\b', r'\bcsv\b',
            r'\bexcel\b', r'\bspreadsheet\b', r'\bdataset\b'
        ]
        if any(re.search(pattern, prompt_lower) for pattern in data_analysis_indicators):
            return MVPFeatureType.DATA_ANALYSIS
        
        # Check for RAG indicators
        rag_indicators = [
            r'\bdocument\b', r'\bpdf\b', r'\btext\b', r'\bextract\b', r'\bsummarize\b',
            r'\bretrieve\b', r'\bquestion answering\b', r'\bdocument qa\b', r'\brag\b',
            r'\bknowledge base\b', r'\bupload\b', r'\bfile\b'
        ]
        if any(re.search(pattern, prompt_lower) for pattern in rag_indicators):
            return MVPFeatureType.RAG
        
        # Check for code generation indicators
        code_indicators = [
            r'\bcode\b', r'\bprogram\b', r'\bdevelop\b', r'\bapplication\b', r'\bsoftware\b',
            r'\bfunction\b', r'\bclass\b', r'\bscript\b', r'\bpython\b', r'\bjavascript\b',
            r'\bjava\b', r'\bc\+\+\b', r'\bc#\b', r'\bruby\b', r'\bgo\b', r'\bphp\b',
            r'\bimplementation\b', r'\balgorithm\b', r'\bapi\b', r'\bweb app\b', r'\bmobile app\b'
        ]
        if any(re.search(pattern, prompt_lower) for pattern in code_indicators):
            return MVPFeatureType.CODE_GENERATION
        
        # Default to general
        return MVPFeatureType.GENERAL
    
    def _generate_default_analysis(self, feature_type: MVPFeatureType, document_ids: List[str] = None) -> TaskAnalysis:
        """
        Generate a default analysis for general tasks.
        
        Args:
            feature_type: The detected feature type
            document_ids: Optional list of document IDs for RAG
            
        Returns:
            Default TaskAnalysis object
        """
        task_id = f"task_{uuid.uuid4().hex[:8]}"
        
        # Create default agent specs
        required_agents = self._get_specialized_agents(feature_type)
        
        if not required_agents:
            required_agents = self._generate_default_agents()
        
        # Create default dependencies
        dependencies = self._generate_default_dependencies(required_agents)
        
        # Get uploaded documents for RAG
        uploaded_documents = []
        if feature_type == MVPFeatureType.RAG and document_ids:
            for doc_id in document_ids:
                doc = self.document_manager.get_document(doc_id)
                if doc:
                    uploaded_documents.append(doc)
        
        return TaskAnalysis(
            task_id=task_id,
            complexity=4,
            estimated_time="5-10 minutes",
            required_agents=required_agents,
            workflow_type=WorkflowType.SEQUENTIAL,
            dependencies=dependencies,
            feature_type=feature_type,
            uploaded_documents=uploaded_documents
        )
    
    def _get_specialized_agents(self, feature_type: MVPFeatureType) -> List[AgentSpec]:
        """
        Get specialized agents for the detected feature type.
        
        Args:
            feature_type: The detected feature type
            
        Returns:
            List of AgentSpec objects for the feature type
        """
        if feature_type == MVPFeatureType.RESEARCH:
            return [
                AgentSpec(
                    role="Research Specialist",
                    goal="Find comprehensive and accurate information on the research topic",
                    backstory="An expert researcher with skills in gathering, analyzing, and synthesizing information from various sources. I excel at finding accurate and relevant information.",
                    tools=["web_search"],
                    allow_delegation=True
                ),
                AgentSpec(
                    role="Fact Checker",
                    goal="Verify the accuracy of information and identify potential biases or inconsistencies",
                    backstory="A meticulous fact checker with a strong attention to detail. I ensure that all information is accurate, properly sourced, and unbiased.",
                    tools=["web_search"],
                    allow_delegation=True
                ),
                AgentSpec(
                    role="Information Synthesizer",
                    goal="Synthesize research findings into a coherent and comprehensive report",
                    backstory="An expert at organizing and synthesizing complex information. I create clear, structured reports that present research findings in an accessible way.",
                    tools=[],
                    allow_delegation=True
                )
            ]
        elif feature_type == MVPFeatureType.YOUTUBE:
            return [
                AgentSpec(
                    role="YouTube Content Finder",
                    goal="Find the most relevant and high-quality YouTube videos on the specified topic",
                    backstory="A specialist in discovering valuable video content across YouTube. I can find educational, entertaining, and informative videos tailored to specific needs.",
                    tools=["youtube_search"],
                    allow_delegation=True
                ),
                AgentSpec(
                    role="Video Content Analyzer",
                    goal="Analyze video content to determine relevance, quality, and educational value",
                    backstory="An expert in evaluating video content for its relevance, accuracy, production quality, and educational value. I can identify the most valuable videos on any topic.",
                    tools=[],
                    allow_delegation=True
                ),
                AgentSpec(
                    role="Content Recommender",
                    goal="Create a curated list of recommended videos with explanations",
                    backstory="A curator skilled in organizing video recommendations into coherent learning paths or collections. I create personalized video recommendations that meet specific needs.",
                    tools=[],
                    allow_delegation=True
                )
            ]
        elif feature_type == MVPFeatureType.DATA_ANALYSIS:
            return [
                AgentSpec(
                    role="Data Cleaning Specialist",
                    goal="Clean and prepare data for analysis, addressing missing values, outliers, and inconsistencies",
                    backstory="An expert in data cleaning and preparation with meticulous attention to detail. I ensure data is ready for accurate analysis.",
                    tools=["data_analysis"],
                    allow_delegation=True
                ),
                AgentSpec(
                    role="Data Analyst",
                    goal="Analyze data to extract meaningful insights and patterns",
                    backstory="A skilled data analyst with expertise in statistical methods and pattern recognition. I transform raw data into meaningful insights.",
                    tools=["data_analysis"],
                    allow_delegation=True
                ),
                AgentSpec(
                    role="Data Visualization Specialist",
                    goal="Create clear and informative visualizations that effectively communicate data insights",
                    backstory="An expert in data visualization who knows how to present data in the most compelling and informative way. I translate complex data into accessible visual stories.",
                    tools=["data_analysis"],
                    allow_delegation=True
                ),
                AgentSpec(
                    role="Insights Interpreter",
                    goal="Interpret data analysis results to provide actionable insights and recommendations",
                    backstory="A specialist in translating data findings into practical business insights. I help bridge the gap between raw analysis and strategic decision-making.",
                    tools=[],
                    allow_delegation=True
                )
            ]
        elif feature_type == MVPFeatureType.RAG:
            return [
                AgentSpec(
                    role="Document Processor",
                    goal="Process and analyze uploaded documents to extract key information",
                    backstory="An expert in document analysis and information extraction. I can quickly identify and extract relevant information from various document types.",
                    tools=["document_qa"],
                    allow_delegation=True
                ),
                AgentSpec(
                    role="Information Retriever",
                    goal="Retrieve relevant information from processed documents based on queries",
                    backstory="A specialist in information retrieval with expertise in semantic search techniques. I can find the most relevant information for any query.",
                    tools=["document_qa", "web_search"],
                    allow_delegation=True
                ),
                AgentSpec(
                    role="Answer Generator",
                    goal="Generate comprehensive and accurate answers based on retrieved information",
                    backstory="An expert in generating clear, concise, and informative answers based on retrieved information. I ensure answers are accurate and properly contextualized.",
                    tools=[],
                    allow_delegation=True
                )
            ]
        elif feature_type == MVPFeatureType.CODE_GENERATION:
            return [
                AgentSpec(
                    role="Requirements Analyst",
                    goal="Analyze and clarify software requirements to ensure clear understanding",
                    backstory="A requirements specialist who excels at understanding and defining software needs. I translate user requests into clear technical requirements.",
                    tools=[],
                    allow_delegation=True
                ),
                AgentSpec(
                    role="Software Architect",
                    goal="Design the overall structure and component relationships of the software",
                    backstory="An experienced software architect with expertise in designing elegant, scalable software systems. I create blueprints that guide development.",
                    tools=[],
                    allow_delegation=True
                ),
                AgentSpec(
                    role="Code Generator",
                    goal="Generate clean, efficient, and well-documented code based on requirements",
                    backstory="A skilled programmer with expertise in multiple programming languages. I write high-quality, maintainable code that meets requirements.",
                    tools=["code_generation"],
                    allow_delegation=True
                ),
                AgentSpec(
                    role="Software Tester",
                    goal="Review code for bugs, edge cases, and potential improvements",
                    backstory="A meticulous tester with a knack for finding edge cases and potential issues. I ensure code is robust, efficient, and ready for production.",
                    tools=[],
                    allow_delegation=True
                ),
                AgentSpec(
                    role="Technical Documentation Writer",
                    goal="Create clear, comprehensive documentation for the generated code",
                    backstory="A documentation specialist who excels at explaining complex technical concepts clearly. I create documentation that helps users understand and use the code effectively.",
                    tools=[],
                    allow_delegation=True
                )
            ]
        
        # Return None for general type (will use default agents)
        return None
    
    def _generate_default_agents(self) -> List[AgentSpec]:
        """
        Generate default agent specifications.
        
        Returns:
            List of default AgentSpec objects
        """
        return [
            AgentSpec(
                role="Task Manager",
                goal="Manage and execute the requested task efficiently",
                backstory="A versatile agent capable of handling diverse requests",
                tools=["web_search", "text_processing"],
                allow_delegation=True
            ),
            AgentSpec(
                role="Content Creator",
                goal="Generate high-quality content based on requirements",
                backstory="A creative agent with strong writing and synthesis abilities",
                tools=["text_generation", "content_formatting"],
                allow_delegation=False
            )
        ]
    
    def _generate_default_dependencies(self, agents: List[AgentSpec]) -> Dict[str, List[str]]:
        """
        Generate default dependencies for agents.
        
        Args:
            agents: List of agent specifications
            
        Returns:
            Dictionary of dependencies
        """
        dependencies = {}
        
        # Add each agent to the dependencies dict
        for i, agent in enumerate(agents):
            if i == 0:
                # First agent has no dependencies
                dependencies[agent.role] = []
            else:
                # Subsequent agents depend on the previous agent
                dependencies[agent.role] = [agents[i-1].role]
        
        return dependencies