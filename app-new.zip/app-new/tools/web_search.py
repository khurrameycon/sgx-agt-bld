# app/tools/web_search.py
import logging
import json
import os
import requests
from typing import Dict, List, Any, Optional

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class WebSearchTool:
    """A real web search tool that searches the web using SerpAPI."""
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize the web search tool.
        
        Args:
            api_key: SerpAPI API key (or use environment variable)
        """
        self.name = "web_search"
        self.description = "Search the web for information on a given topic"
        self.api_key = api_key or os.environ.get("SERPAPI_KEY")
        
        if not self.api_key:
            logger.warning("No SerpAPI key provided. Will use simulated results.")
    
    def __call__(self, query: str, num_results: int = 5) -> str:
        """
        Search the web for the given query.
        
        Args:
            query: The search query
            num_results: Number of results to return
            
        Returns:
            Search results as a formatted string
        """
        logger.info(f"Performing web search for: {query}")
        
        if self.api_key:
            try:
                # Use SerpAPI for real search results
                results = self._real_search(query, num_results)
            except Exception as e:
                logger.error(f"Error using SerpAPI: {e}")
                # Fall back to simulated results
                results = self._simulate_search_results(query, num_results)
        else:
            # Use simulated results if no API key
            results = self._simulate_search_results(query, num_results)
        
        # Format the results
        formatted_results = self._format_results(results)
        
        return formatted_results
    
    def _real_search(self, query: str, num_results: int = 5) -> List[Dict[str, str]]:
        """
        Perform a real web search using SerpAPI.
        
        Args:
            query: The search query
            num_results: Number of results to return
            
        Returns:
            List of search results
        """
        params = {
            "engine": "google",
            "q": query,
            "api_key": self.api_key,
            "num": num_results
        }
        
        response = requests.get("https://serpapi.com/search", params=params)
        response.raise_for_status()
        data = response.json()
        
        results = []
        if "organic_results" in data:
            for result in data["organic_results"][:num_results]:
                results.append({
                    "title": result.get("title", "No title"),
                    "snippet": result.get("snippet", "No description available"),
                    "url": result.get("link", "No URL available"),
                })
        
        # Add knowledge graph if available
        if "knowledge_graph" in data:
            kg = data["knowledge_graph"]
            results.insert(0, {
                "title": kg.get("title", "Knowledge Graph"),
                "snippet": kg.get("description", "No description available"),
                "url": kg.get("source", {}).get("link", "No URL available"),
            })
        
        return results
    
    def _simulate_search_results(self, query: str, num_results: int = 5) -> List[Dict[str, str]]:
        """
        Simulate search results for the given query.
        
        Args:
            query: The search query
            num_results: Number of results to return
            
        Returns:
            List of simulated search results
        """
        # Clean and normalize the query
        clean_query = query.lower().strip()
        
        # Generate mock results based on the query
        results = []
        
        for i in range(min(num_results, 7)):
            result = {
                "title": f"Result {i+1} for {clean_query}",
                "snippet": f"This is a simulated search result for '{clean_query}'. "
                           f"It contains information that might be relevant to your query. "
                           f"In a real implementation, this would contain actual content from the web.",
                "url": f"https://example.com/result/{i+1}?q={clean_query.replace(' ', '+')}",
            }
            results.append(result)
        
        return results
    
    def _format_results(self, results: List[Dict[str, str]]) -> str:
        """
        Format the search results into a readable string.
        
        Args:
            results: List of search results
            
        Returns:
            Formatted search results
        """
        if not results:
            return "No results found."
        
        formatted = "Search Results:\n\n"
        
        for i, result in enumerate(results):
            formatted += f"{i+1}. {result['title']}\n"
            formatted += f"   URL: {result['url']}\n"
            formatted += f"   {result['snippet']}\n\n"
        
        return formatted


# Factory function to create the tool
def create_web_search_tool(api_key: Optional[str] = None):
    """Create and return a web search tool instance."""
    return WebSearchTool(api_key)