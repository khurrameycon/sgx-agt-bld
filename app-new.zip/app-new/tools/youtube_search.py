# app/tools/youtube_search.py
import logging
import os
import requests
from typing import Dict, List, Any, Optional
from datetime import datetime
import re

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class YouTubeSearchTool:
    """Tool for searching YouTube videos."""
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize the YouTube search tool.
        
        Args:
            api_key: YouTube Data API key (or use environment variable)
        """
        self.name = "youtube_search"
        self.description = "Search for YouTube videos on a specific topic"
        self.api_key = api_key or os.environ.get("YOUTUBE_API_KEY")
        
        if not self.api_key:
            logger.warning("No YouTube API key provided. Will use simulated results.")
    
    def __call__(self, query: str, max_results: int = 5, include_details: bool = True) -> str:
        """
        Search for YouTube videos.
        
        Args:
            query: Search query
            max_results: Maximum number of results to return
            include_details: Whether to include video details
            
        Returns:
            Formatted search results
        """
        logger.info(f"Searching YouTube for: {query}")
        
        if self.api_key:
            try:
                # Use YouTube Data API for real search results
                results = self._real_search(query, max_results)
            except Exception as e:
                logger.error(f"Error using YouTube API: {e}")
                # Fall back to simulated results
                results = self._simulate_search_results(query, max_results)
        else:
            # Use simulated results if no API key
            results = self._simulate_search_results(query, max_results)
        
        # Get additional details if requested
        if include_details and self.api_key:
            results = self._enrich_with_details(results)
        
        # Format the results
        formatted_results = self._format_results(results)
        
        return formatted_results
    
    def _real_search(self, query: str, max_results: int = 5) -> List[Dict[str, Any]]:
        """
        Perform a real YouTube search using the API.
        
        Args:
            query: Search query
            max_results: Maximum number of results
            
        Returns:
            List of video information
        """
        url = "https://www.googleapis.com/youtube/v3/search"
        params = {
            "part": "snippet",
            "q": query,
            "maxResults": max_results,
            "type": "video",
            "key": self.api_key
        }
        
        response = requests.get(url, params=params)
        response.raise_for_status()
        data = response.json()
        
        results = []
        if "items" in data:
            for item in data["items"]:
                video_id = item["id"]["videoId"]
                snippet = item["snippet"]
                
                results.append({
                    "video_id": video_id,
                    "title": snippet.get("title", "No title"),
                    "description": snippet.get("description", "No description available"),
                    "thumbnail": snippet.get("thumbnails", {}).get("medium", {}).get("url", ""),
                    "channel_title": snippet.get("channelTitle", "Unknown channel"),
                    "published_at": snippet.get("publishedAt", ""),
                    "url": f"https://www.youtube.com/watch?v={video_id}"
                })
        
        return results
    
    def _enrich_with_details(self, videos: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Enrich video results with additional details.
        
        Args:
            videos: List of videos with basic information
            
        Returns:
            Videos with additional details
        """
        if not videos:
            return videos
        
        # Get video ids
        video_ids = [video["video_id"] for video in videos]
        
        # Make API request for details
        url = "https://www.googleapis.com/youtube/v3/videos"
        params = {
            "part": "contentDetails,statistics",
            "id": ",".join(video_ids),
            "key": self.api_key
        }
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            data = response.json()
            
            # Create lookup dictionary
            details_lookup = {}
            if "items" in data:
                for item in data["items"]:
                    video_id = item["id"]
                    content_details = item.get("contentDetails", {})
                    statistics = item.get("statistics", {})
                    
                    details_lookup[video_id] = {
                        "duration": self._format_duration(content_details.get("duration", "PT0S")),
                        "view_count": int(statistics.get("viewCount", 0)),
                        "like_count": int(statistics.get("likeCount", 0)),
                        "comment_count": int(statistics.get("commentCount", 0))
                    }
            
            # Enrich original videos
            for video in videos:
                video_id = video["video_id"]
                if video_id in details_lookup:
                    video.update(details_lookup[video_id])
                else:
                    # Default values if details not available
                    video.update({
                        "duration": "Unknown",
                        "view_count": 0,
                        "like_count": 0,
                        "comment_count": 0
                    })
            
            return videos
        except Exception as e:
            logger.error(f"Error enriching videos with details: {e}")
            return videos
    
    def _format_duration(self, iso_duration: str) -> str:
        """
        Format ISO 8601 duration to human-readable format.
        
        Args:
            iso_duration: ISO 8601 duration string (e.g., PT1H30M15S)
            
        Returns:
            Human-readable duration (e.g., 1:30:15)
        """
        match = re.match(
            r'P(?:(\d+)D)?T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?',
            iso_duration
        )
        
        if not match:
            return "Unknown"
        
        days, hours, minutes, seconds = match.groups()
        
        # Convert to integers, defaulting to 0 if None
        days = int(days) if days else 0
        hours = int(hours) if hours else 0
        minutes = int(minutes) if minutes else 0
        seconds = int(seconds) if seconds else 0
        
        # Add days to hours
        hours += days * 24
        
        # Format
        if hours > 0:
            return f"{hours}:{minutes:02d}:{seconds:02d}"
        else:
            return f"{minutes:02d}:{seconds:02d}"
    
    def _simulate_search_results(self, query: str, max_results: int = 5) -> List[Dict[str, Any]]:
        """
        Simulate YouTube search results for the given query.
        
        Args:
            query: Search query
            max_results: Maximum number of results
            
        Returns:
            List of simulated video information
        """
        # Clean and normalize the query
        clean_query = query.lower().strip()
        
        # Generate mock results based on the query
        results = []
        
        for i in range(min(max_results, 5)):
            video_id = f"simulated{i+1}"
            
            # Create a more realistic title based on the query
            topics = clean_query.split()
            topic_word = topics[0] if topics else "topic"
            
            titles = [
                f"Complete Guide to {clean_query.title()} - Tutorial for Beginners",
                f"Understanding {clean_query.title()} in 2025 - What You Need to Know",
                f"Top 10 {clean_query.title()} Tips and Tricks",
                f"{clean_query.title()} Masterclass - From Novice to Expert",
                f"The Ultimate {clean_query.title()} Explained Simply"
            ]
            
            result = {
                "video_id": video_id,
                "title": titles[i % len(titles)],
                "description": f"This simulated video covers everything about {clean_query}. "
                               f"It explains key concepts and provides practical examples. "
                               f"In a real implementation, this would be an actual YouTube video description.",
                "thumbnail": f"https://example.com/thumbnail/{video_id}.jpg",
                "channel_title": f"{topic_word.title()} Expert",
                "published_at": datetime.now().isoformat(),
                "url": f"https://www.youtube.com/watch?v={video_id}",
                "duration": f"{(i+1)*5}:30",
                "view_count": (i+1) * 10000,
                "like_count": (i+1) * 800,
                "comment_count": (i+1) * 150
            }
            results.append(result)
        
        return results
    
    def _format_results(self, results: List[Dict[str, Any]]) -> str:
        """
        Format the YouTube search results into a readable string.
        
        Args:
            results: List of video information
            
        Returns:
            Formatted search results
        """
        if not results:
            return "No YouTube videos found."
        
        formatted = "YouTube Search Results:\n\n"
        
        for i, video in enumerate(results):
            formatted += f"{i+1}. {video['title']}\n"
            formatted += f"   Channel: {video['channel_title']}\n"
            formatted += f"   URL: {video['url']}\n"
            
            # Add details if available
            details = []
            if "duration" in video:
                details.append(f"Duration: {video['duration']}")
            if "view_count" in video:
                details.append(f"Views: {video['view_count']:,}")
            if "like_count" in video:
                details.append(f"Likes: {video['like_count']:,}")
            
            if details:
                formatted += f"   {' | '.join(details)}\n"
            
            # Add description
            description = video['description']
            if len(description) > 150:
                description = description[:147] + "..."
            formatted += f"   {description}\n\n"
        
        return formatted


# Factory function to create the tool
def create_youtube_search_tool(api_key: Optional[str] = None):
    """Create and return a YouTube search tool instance."""
    return YouTubeSearchTool(api_key)