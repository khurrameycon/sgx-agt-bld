# app/tools/data_analysis.py
import logging
import os
import pandas as pd
import numpy as np
import tempfile
from typing import Dict, List, Any, Optional, Union
import json
import matplotlib.pyplot as plt
import io
import base64

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DataAnalysisTool:
    """Tool for analyzing data from CSV, Excel, and other formats."""
    
    def __init__(self):
        """Initialize the data analysis tool."""
        self.name = "data_analysis"
        self.description = "Analyze data from various formats (CSV, Excel, JSON)"
        self.temp_dir = tempfile.mkdtemp(prefix="sagax1_data_")
        self._ensure_temp_dir()
    
    def __call__(self, data: str, format: str = "csv", analysis_type: str = "summary") -> str:
        """
        Analyze the provided data.
        
        Args:
            data: The data to analyze (file content or path to file)
            format: The format of the data (csv, excel, json)
            analysis_type: Type of analysis to perform (summary, correlations, 
                          visualize_hist, visualize_scatter, etc.)
            
        Returns:
            Analysis results as a formatted string
        """
        logger.info(f"Performing {analysis_type} analysis on {format} data")
        
        try:
            # Load the data
            df = self._load_data(data, format)
            
            # Check if dataframe is valid
            if df is None or df.empty:
                return "Error: No data to analyze or data format incorrect"
            
            # Perform the requested analysis
            if analysis_type == "summary":
                return self._summary_analysis(df)
            elif analysis_type == "correlations":
                return self._correlation_analysis(df)
            elif analysis_type == "visualize_hist":
                return self._visualize_histogram(df)
            elif analysis_type == "visualize_scatter":
                return self._visualize_scatter(df)
            elif analysis_type == "full":
                return self._full_analysis(df)
            else:
                return f"Unknown analysis type: {analysis_type}. Available types: summary, correlations, visualize_hist, visualize_scatter, full"
                
        except Exception as e:
            logger.error(f"Error analyzing data: {e}")
            return f"Error analyzing data: {str(e)}"
    
    def _ensure_temp_dir(self):
        """Ensure the temporary directory exists."""
        os.makedirs(self.temp_dir, exist_ok=True)
    
    def _load_data(self, data: str, format: str) -> Optional[pd.DataFrame]:
        """
        Load data into a pandas DataFrame.
        
        Args:
            data: The data to load (file content or path)
            format: The format of the data
            
        Returns:
            Pandas DataFrame with the loaded data, or None if loading fails
        """
        try:
            # Check if data is a file path
            if os.path.isfile(data):
                if format.lower() == "csv":
                    return pd.read_csv(data)
                elif format.lower() in ["excel", "xlsx", "xls"]:
                    return pd.read_excel(data)
                elif format.lower() == "json":
                    return pd.read_json(data)
                else:
                    logger.error(f"Unsupported file format: {format}")
                    return None
            else:
                # Create a temporary file with the data
                temp_file = os.path.join(self.temp_dir, f"temp_data.{format}")
                with open(temp_file, 'w') as f:
                    f.write(data)
                
                # Load from the temporary file
                if format.lower() == "csv":
                    return pd.read_csv(temp_file)
                elif format.lower() in ["excel", "xlsx", "xls"]:
                    return pd.read_excel(temp_file)
                elif format.lower() == "json":
                    return pd.read_json(temp_file)
                else:
                    logger.error(f"Unsupported file format: {format}")
                    return None
                    
        except Exception as e:
            logger.error(f"Error loading data: {e}")
            
            # Try alternative approaches for common formats
            if format.lower() == "csv":
                try:
                    # Try with different delimiters
                    for delimiter in [',', ';', '\t', '|']:
                        try:
                            return pd.read_csv(io.StringIO(data), delimiter=delimiter)
                        except:
                            continue
                except:
                    pass
            
            # Try parsing as JSON
            if format.lower() == "json":
                try:
                    # If it's a JSON array of objects
                    return pd.json_normalize(json.loads(data))
                except:
                    pass
            
            return None
    
    def _summary_analysis(self, df: pd.DataFrame) -> str:
        """
        Perform a summary analysis of the data.
        
        Args:
            df: DataFrame to analyze
            
        Returns:
            Summary analysis as a formatted string
        """
        result = "Data Summary Analysis:\n\n"
        
        # Basic info
        result += f"Dimensions: {df.shape[0]} rows, {df.shape[1]} columns\n\n"
        
        # Column names and types
        result += "Columns:\n"
        for col, dtype in df.dtypes.items():
            result += f"- {col} ({dtype})\n"
        result += "\n"
        
        # Check for missing values
        missing = df.isnull().sum()
        if missing.sum() > 0:
            result += "Missing Values:\n"
            for col, count in missing.items():
                if count > 0:
                    percentage = (count / df.shape[0]) * 100
                    result += f"- {col}: {count} ({percentage:.2f}%)\n"
            result += "\n"
        else:
            result += "No missing values found.\n\n"
        
        # Statistical summary for numeric columns
        numeric_cols = df.select_dtypes(include=['number']).columns
        if not numeric_cols.empty:
            result += "Numeric Columns Statistics:\n"
            stats = df[numeric_cols].describe().transpose()
            for col, row in stats.iterrows():
                result += f"- {col}:\n"
                result += f"  - Min: {row['min']:.2f}, Max: {row['max']:.2f}\n"
                result += f"  - Mean: {row['mean']:.2f}, Median: {df[col].median():.2f}\n"
                result += f"  - Std Dev: {row['std']:.2f}\n"
            result += "\n"
        
        # Categorical columns summary
        cat_cols = df.select_dtypes(include=['object', 'category']).columns
        if not cat_cols.empty:
            result += "Categorical Columns:\n"
            for col in cat_cols:
                value_counts = df[col].value_counts()
                top_values = value_counts.head(5)
                result += f"- {col}: {df[col].nunique()} unique values\n"
                result += "  - Top values:\n"
                for val, count in top_values.items():
                    percentage = (count / df.shape[0]) * 100
                    result += f"    - {val}: {count} ({percentage:.2f}%)\n"
            result += "\n"
        
        return result
    
    def _correlation_analysis(self, df: pd.DataFrame) -> str:
        """
        Perform a correlation analysis on numeric columns.
        
        Args:
            df: DataFrame to analyze
            
        Returns:
            Correlation analysis as a formatted string
        """
        numeric_cols = df.select_dtypes(include=['number']).columns
        
        if numeric_cols.empty:
            return "No numeric columns found to calculate correlations."
        
        result = "Correlation Analysis:\n\n"
        
        # Calculate correlations
        corr_matrix = df[numeric_cols].corr()
        
        # Get top positive and negative correlations
        correlations = []
        for i in range(len(corr_matrix.columns)):
            for j in range(i+1, len(corr_matrix.columns)):
                col1 = corr_matrix.columns[i]
                col2 = corr_matrix.columns[j]
                correlations.append((col1, col2, corr_matrix.iloc[i, j]))
        
        # Sort by absolute correlation value
        correlations.sort(key=lambda x: abs(x[2]), reverse=True)
        
        # Top 10 strongest correlations
        result += "Top Correlations:\n"
        for col1, col2, corr in correlations[:10]:
            result += f"- {col1} and {col2}: {corr:.4f}\n"
        
        # Correlation interpretation
        result += "\nCorrelation Interpretation:\n"
        result += "- Above 0.7: Strong positive correlation\n"
        result += "- 0.5 to 0.7: Moderate positive correlation\n"
        result += "- 0.3 to 0.5: Weak positive correlation\n"
        result += "- -0.3 to 0.3: Little to no correlation\n"
        result += "- -0.5 to -0.3: Weak negative correlation\n"
        result += "- -0.7 to -0.5: Moderate negative correlation\n"
        result += "- Below -0.7: Strong negative correlation\n"
        
        return result
    
    def _visualize_histogram(self, df: pd.DataFrame) -> str:
        """
        Create histograms for numeric columns and return them as base64 strings.
        
        Args:
            df: DataFrame to visualize
            
        Returns:
            Description with links to histogram images
        """
        numeric_cols = df.select_dtypes(include=['number']).columns[:5]  # Limit to 5 columns
        
        if numeric_cols.empty:
            return "No numeric columns found to create histograms."
        
        result = "Histogram Visualizations:\n\n"
        result += "Histograms have been generated for the numeric columns. "
        result += "To view them, please check the attached files or use a visualization tool like matplotlib.\n\n"
        
        try:
            # Create histograms
            plt.figure(figsize=(12, 8))
            for i, col in enumerate(numeric_cols):
                plt.subplot(2, 3, i+1)
                df[col].hist(bins=20)
                plt.title(f'Histogram of {col}')
                plt.tight_layout()
            
            # Save to a temporary file
            img_path = os.path.join(self.temp_dir, "histograms.png")
            plt.savefig(img_path)
            plt.close()
            
            # Convert to base64 for embedding
            with open(img_path, "rb") as image_file:
                b64_string = base64.b64encode(image_file.read()).decode()
            
            result += f"Histograms have been saved to: {img_path}\n"
            result += "Please note: In a web interface, these would be displayed directly.\n"
            
        except Exception as e:
            logger.error(f"Error creating histograms: {e}")
            result += f"Error creating histograms: {str(e)}\n"
        
        return result
    
    def _visualize_scatter(self, df: pd.DataFrame) -> str:
        """
        Create scatter plots for pairs of numeric columns and return them as base64 strings.
        
        Args:
            df: DataFrame to visualize
            
        Returns:
            Description with links to scatter plot images
        """
        numeric_cols = df.select_dtypes(include=['number']).columns[:4]  # Limit to 4 columns
        
        if len(numeric_cols) < 2:
            return "Not enough numeric columns found to create scatter plots."
        
        result = "Scatter Plot Visualizations:\n\n"
        result += "Scatter plots have been generated for pairs of numeric columns. "
        result += "To view them, please check the attached files or use a visualization tool like matplotlib.\n\n"
        
        try:
            # Create scatter plots for pairs of columns
            num_plots = min(6, len(numeric_cols) * (len(numeric_cols) - 1) // 2)
            plt.figure(figsize=(15, 10))
            
            plot_count = 0
            for i in range(len(numeric_cols)):
                for j in range(i+1, len(numeric_cols)):
                    if plot_count >= num_plots:
                        break
                    
                    plt.subplot(2, 3, plot_count+1)
                    plt.scatter(df[numeric_cols[i]], df[numeric_cols[j]], alpha=0.5)
                    plt.xlabel(numeric_cols[i])
                    plt.ylabel(numeric_cols[j])
                    plt.title(f'{numeric_cols[i]} vs {numeric_cols[j]}')
                    plot_count += 1
            
            plt.tight_layout()
            
            # Save to a temporary file
            img_path = os.path.join(self.temp_dir, "scatterplots.png")
            plt.savefig(img_path)
            plt.close()
            
            # Convert to base64 for embedding
            with open(img_path, "rb") as image_file:
                b64_string = base64.b64encode(image_file.read()).decode()
            
            result += f"Scatter plots have been saved to: {img_path}\n"
            result += "Please note: In a web interface, these would be displayed directly.\n"
            
        except Exception as e:
            logger.error(f"Error creating scatter plots: {e}")
            result += f"Error creating scatter plots: {str(e)}\n"
        
        return result
    
    def _full_analysis(self, df: pd.DataFrame) -> str:
        """
        Perform a full analysis of the data, combining all analysis types.
        
        Args:
            df: DataFrame to analyze
            
        Returns:
            Full analysis as a formatted string
        """
        result = "# Full Data Analysis Report\n\n"
        
        # Add summary analysis
        result += "## 1. Summary Analysis\n\n"
        result += self._summary_analysis(df)
        result += "\n"
        
        # Add correlation analysis if applicable
        if not df.select_dtypes(include=['number']).columns.empty:
            result += "## 2. Correlation Analysis\n\n"
            result += self._correlation_analysis(df)
            result += "\n"
        
        # Add visualization references
        result += "## 3. Visualizations\n\n"
        result += "Visualizations have been generated separately. "
        result += "Please check the attached files or use the visualization functions directly.\n\n"
        
        # Add recommendations and insights
        result += "## 4. Recommendations and Insights\n\n"
        
        # Missing values recommendations
        missing = df.isnull().sum()
        if missing.sum() > 0:
            result += "### Missing Values Handling\n\n"
            for col, count in missing.items():
                if count > 0:
                    percentage = (count / df.shape[0]) * 100
                    if percentage > 50:
                        result += f"- {col}: High missing rate ({percentage:.2f}%). Consider dropping this column.\n"
                    elif percentage > 20:
                        result += f"- {col}: Moderate missing rate ({percentage:.2f}%). Consider imputation with median/mode.\n"
                    else:
                        result += f"- {col}: Low missing rate ({percentage:.2f}%). Standard imputation should work well.\n"
            result += "\n"
        
        # Outlier detection for numeric columns
        numeric_cols = df.select_dtypes(include=['number']).columns
        if not numeric_cols.empty:
            result += "### Potential Outliers\n\n"
            for col in numeric_cols:
                q1 = df[col].quantile(0.25)
                q3 = df[col].quantile(0.75)
                iqr = q3 - q1
                lower_bound = q1 - 1.5 * iqr
                upper_bound = q3 + 1.5 * iqr
                outliers = df[(df[col] < lower_bound) | (df[col] > upper_bound)][col].count()
                
                if outliers > 0:
                    percentage = (outliers / df.shape[0]) * 100
                    result += f"- {col}: {outliers} potential outliers ({percentage:.2f}%).\n"
            result += "\n"
        
        # Insights based on data characteristics
        result += "### Data Insights\n\n"
        
        # Check for skewness in numeric distributions
        for col in numeric_cols:
            skewness = df[col].skew()
            if abs(skewness) > 1:
                result += f"- {col} has a {'positive' if skewness > 0 else 'negative'} skew ({skewness:.2f}). "
                result += "Consider transformations for statistical analyses.\n"
        
        return result


# Factory function to create the tool
def create_data_analysis_tool():
    """Create and return a data analysis tool instance."""
    return DataAnalysisTool()