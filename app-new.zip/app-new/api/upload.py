# app/api/upload.py
import os
import tempfile
import logging
from typing import List, Dict, Any, Optional
from fastapi import APIRouter, File, UploadFile, HTTPException, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import uuid

from app.models import DocumentUploadResponse
from app.core.document_manager import DocumentManager

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

router = APIRouter()

# Dependency
def get_document_manager():
    """Get the document manager."""
    return DocumentManager()

@router.post("/upload", response_model=DocumentUploadResponse)
async def upload_file(
    file: UploadFile = File(...),
    document_manager: DocumentManager = Depends(get_document_manager)
):
    """
    Upload a file for processing with RAG.
    
    Args:
        file: The file to upload
        document_manager: Document manager instance
        
    Returns:
        Document upload information
    """
    try:
        logger.info(f"Received file upload: {file.filename}")
        
        # Validate file type
        valid_extensions = [".pdf", ".docx", ".doc", ".txt", ".md", ".csv", ".json"]
        file_ext = os.path.splitext(file.filename)[1].lower()
        
        if file_ext not in valid_extensions:
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported file type. Supported types: {', '.join(valid_extensions)}"
            )
        
        # Create a temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix=file_ext) as temp:
            # Write the file content
            content = await file.read()
            temp.write(content)
            temp_path = temp.name
        
        try:
            # Process the file with the document manager
            document_info = document_manager.save_uploaded_document(temp_path, file.filename)
            
            # Create response
            response = DocumentUploadResponse(
                document_id=os.path.basename(os.path.splitext(document_info.file_path)[0]),
                filename=document_info.filename,
                file_size=document_info.file_size,
                status="success"
            )
            
            return response
            
        finally:
            # Clean up the temporary file
            os.unlink(temp_path)
            
    except Exception as e:
        logger.error(f"Error processing file upload: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Error processing file upload: {str(e)}"
        )

@router.get("/documents", response_model=List[Dict[str, Any]])
async def list_documents(
    document_manager: DocumentManager = Depends(get_document_manager)
):
    """
    List all uploaded documents.
    
    Args:
        document_manager: Document manager instance
        
    Returns:
        List of document information
    """
    try:
        documents = document_manager.list_documents()
        
        # Format the response
        result = []
        for doc in documents:
            doc_id = os.path.basename(os.path.splitext(doc.file_path)[0])
            
            result.append({
                "document_id": doc_id,
                "filename": doc.filename,
                "file_type": doc.file_type,
                "file_size": doc.file_size,
                "embedding_status": doc.embedding_status,
                "upload_date": os.path.getctime(doc.file_path)
            })
        
        return result
        
    except Exception as e:
        logger.error(f"Error listing documents: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Error listing documents: {str(e)}"
        )

@router.delete("/documents/{document_id}")
async def delete_document(
    document_id: str,
    document_manager: DocumentManager = Depends(get_document_manager)
):
    """
    Delete a document.
    
    Args:
        document_id: ID of the document to delete
        document_manager: Document manager instance
        
    Returns:
        Success message
    """
    try:
        document = document_manager.get_document(document_id)
        
        if not document:
            raise HTTPException(
                status_code=404,
                detail="Document not found"
            )
        
        # Delete the document file
        if os.path.exists(document.file_path):
            os.remove(document.file_path)
        
        # Delete the document info file
        doc_info_path = os.path.join(document_manager.documents_path, f"{document_id}.json")
        if os.path.exists(doc_info_path):
            os.remove(doc_info_path)
        
        # Delete any associated chunks and embeddings
        chunk_pattern = f"{document_id}_chunk_"
        for filename in os.listdir(document_manager.chunked_texts_path):
            if chunk_pattern in filename:
                chunk_path = os.path.join(document_manager.chunked_texts_path, filename)
                if os.path.exists(chunk_path):
                    os.remove(chunk_path)
        
        for filename in os.listdir(document_manager.embeddings_path):
            if chunk_pattern in filename:
                embedding_path = os.path.join(document_manager.embeddings_path, filename)
                if os.path.exists(embedding_path):
                    os.remove(embedding_path)
        
        return {"status": "success", "message": f"Document {document_id} deleted successfully"}
        
    except Exception as e:
        logger.error(f"Error deleting document: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Error deleting document: {str(e)}"
        )